import Image from "next/image";
import PadzistDashboard from "./PadzistDashboard";

export default function Home() {
  return (
    <PadzistDashboard />
  );
}
